package monke;

public class Carbon extends Resource{
	
	String GetName() {
		return "carbon";
	}

}
