package monke;

import java.util.ArrayList;
import java.util.Random;

public class Asteroid implements Travel{
	private Game game;
	private int id;
	private int layers;
	private boolean closeToSun;
	private String weather;
	private boolean isEmpty;
	private ArrayList<Creature> creatures;
	private Resource resource;
	private ArrayList<Travel> neighbors;
	private static BillOfResources bill;
	Ellenorzo el;
	/**
	 * Konstruktor.
	 * @param g
	 * @param id
	 * @param r
	 */
	public Asteroid(Game g, int id, Resource r) {
		game = g;
		this.id = id;
		Random rand = new Random();
		layers = rand.nextInt(3) + 3;
		closeToSun = false;
		weather = "normal";
		if(r == null)
			isEmpty = true;
		else
			isEmpty = false;
		creatures = new ArrayList<Creature>();
		resource = r;
		neighbors = new ArrayList<Travel>();
		bill = new BillOfResources();
		g.GetSun().AddAsteroid(this);
		el = new Ellenorzo();
	}
	
	public void Step() {
		if(closeToSun && layers == 0 && resource != null) {
			resource.CloseToSun(this);
		}
	}
	/**
	 * Visszaadja az aszteroida id-jet.
	 * @return Visszater az id-vel.
	 */
	public int GetId() {
		return id;
	}
	/**
	 * Visszaadja, hogy ures-e az aszteroida.
	 * @return  Visszater az isEmpty-vel.
	 */
	public boolean GetIsEmpty() {
		return isEmpty;
	}
	/**
	 * Beallitja az isEmpty booleant.
	 * @param b
	 */
	public void SetIsEmpty(boolean b) {
		isEmpty = b;
	}
	/**
	 * Visszaadja, hogy mekkora az aszteroida kopenye.
	 * @return Visszaadja a layers valtozot.
	 */
	public int GetLayers() {
		return layers;
	}
	/**
	 * Beallitja a layers valtozot.
	 * @param l
	 */
	public void SetLayers(int l) {
		System.out.println("Asteroid layer set successfully!");
		el.SetOsszString("Asteroid layer set successfully!");
		layers = l;
	}
	/**
	 * Visszaadja, hogy milyen nyersanyag van az aszteroidaban.
	 * @return Visszaadja a resource-t.
	 */
	public Resource GetResource() {
		return resource;
	}
	/**
	 * Beallitja a a resource-t.
	 * @param r
	 */
	public void SetResource(Resource r) {
		System.out.println("Asteroid resource set successfully!");
		el.SetOsszString("Asteroid resource set successfully!");
		resource = r;
		if(resource == null) {
			isEmpty = true;
		}
	}
	/**
	 * Visszaadja, hogy az aszteroida napkozelben van-e.
	 * @return Visszaadja a closeToSun booleant.
	 */
	public boolean GetCloseToSun() {
		return closeToSun;
	}
	/**
	 * Beallitja a closeToSun booleant.
	 * @param b
	 */
	public void SetCloseToSun(boolean b) {
		closeToSun = b;
	}
	/**
	 * Visszaadja az aszteroidan levo idojarast.
	 * @return Visszaadja a weather-t.
	 */
	public String GetWeather() {
		return weather;
	}
	/**
	 * Beallitja az idojarast.
	 * @param w
	 */
	public void SetWeather(String w) {
		System.out.println("Weather set successfully!");
		el.SetOsszString("Weather set successfully!");
		weather = w;
	}
	/**
	 * Visszaadja a szomszedos aszteroidak es teleportok listajat
	 * @return Visszaadja a neighbors-t.
	 */
	public ArrayList<Travel> GetNeighbors(){
		return neighbors;
	}
	/**
	 * A megkapott aszteroida vagy teleport hozzaadodik az aszteroida szomszedaihoz.
	 * @param t
	 */
	public void AddNewNeighbor(Travel t) {
		neighbors.add(t);
	}
	/**
	 * A megkapott aszteroida vagy teleport torlodik az aszteroida szomszedai kozul.
	 */
	public void RemoveNeighbor(Travel t) {
		neighbors.remove(t);
	}
	/**
	 * Visszaadja az aszteroidan tartozkodo entitasokat.
	 * @return Visszaadja a creature-ok listajat.
	 */
	public ArrayList<Creature> GetCreatures() {
		return creatures;
	}
	/**
	 * Hozzaadja az entitast az aszteroidahoz.
	 * @param c
	 */
	public void AddCreature(Creature c){
		creatures.add(c);
	}
	/**
	 * Torli az aszteroidarol a megkapott entitast.
	 * @param c
	 */
	public void Remove(Creature c) { 
		creatures.remove(c);
	}
	/**
	 * Csokkenti az aszteroida kopenyet.
	 * Ha epp napkozelben van, akkor meghivja a resource CloseToSun fuggvenyet.
	 */
	public void ReduceLayers() {
		if(layers == 1 && closeToSun) {
			layers--;
			System.out.println("Successful drill!");
			el.SetOsszString("Successful drill!");
			resource.CloseToSun(this);
		}
		else if(layers > 0){
			layers--;
			System.out.println("Successful drill!");
			el.SetOsszString("Successful drill!");
		}
		else {
			System.out.println("The asteroid has no layers, drilling unsuccessful!");
			el.SetOsszString("The asteroid has no layers, drilling unsuccessful!");
		}
	}
	/**
	 * Megnezi, hogy a kapott travel szomszedja-e annak a travelnek amire ez hivva van.
	 * @param t
	 * @return Ha szomszedja, akkor true-val, ha nem, akkor false-al ter vissza.
	 */
	public boolean CheckNeighbor(Travel t) {
		for(Travel tr : neighbors) {
			if(tr.GetOtherAsteroid() == t.GetOtherAsteroid())
				return true;
		}
		return false;
	}
	/**
	 * Napviharnal ha el tudnak bujni az entitasok nem csinal semmit, egyebkent pedig megoli az osszes entitast ami rajta van.
	 */
	public void SunStorm() {
		int size = creatures.size();
		if(layers == 0 && isEmpty);
		else {
			if(creatures != null)
				while(creatures.size() > 0)
					creatures.get(0).Die();
			if(neighbors != null)
				for(Travel t : neighbors)
					t.SetIsMoving();
		}
	}
	/**
	 * Felrobban az aszteroida.
	 */
	public void Explode() {
		if(creatures != null)
			while(creatures.size() > 0) {
				creatures.get(0).Explode();
			}
		if(neighbors != null)
			for(Travel t : neighbors)
				t.RemoveNeighbor(this);
		int count=0;
		for(Asteroid a : game.GetAsteroid()) {
			count++;
			if(a.GetId() == this.GetId()) {
				game.GetAsteroid().remove(count-1);
				break;
			}
		}
		System.out.println("Asteroid exploded!");
		el.SetOsszString("Asteroid exploded!");
	}
	/**
	 * Megnezi, hogy van-e osszesen minden nyersanyagbol harom az aszteroidan levo telepeseknel.
	 * Ha a telepesek osszegyujtottek eleg nyersanyagot, meghivja az EndGame()-et.
	 */
	public void CheckEnoughResources() {
		ArrayList<Resource> all = new ArrayList<>();
		for(Creature c : creatures) {
			if(c.GetResources() != null) {
				for(Resource r : c.GetResources()) {
					all.add(r);
				}
			}
		}
		if(bill.CheckResource(all, "Base")) {
			game.EndGame();
		}
	}
	/**
	 * Teleport elfogadasa.
	 */
	@Override
	public void AcceptTeleport(Teleport t) {
		t.SetAsteroid(this);
		AddNewNeighbor(t);
	}
	/**
	 * Elfogadja a ralepo entitast.
	 */
	@Override
	public void Accept(Creature c) {
		creatures.add(c);
		c.SetAsteroid(this);
	}
	/**
	 * Az isMoving boolean beallitasa.
	 */
	@Override
	public void SetIsMoving() {}
	
	//Innent�l minden �j
	public void GetOtherCreaturesName(Creature ask) {
		String seged = new String();
		seged = "Other creatures on your asteroid: ";
		System.out.print("Other creatures on your asteroid: ");
		for (Creature c : creatures) {
			if(!c.GetName().equals(ask.GetName())) {
				System.out.print(c.GetName()+" ");
				seged = seged + c.GetName()+" ";
			}
		}
		System.out.println();
		el.SetOsszString(seged);
	}
	
	public void GetCreaturesName() {
		String seged = new String();
		seged = "Creatures: ";
		System.out.print("Creatures: ");
		for (Creature c : creatures) {
			System.out.print(c.GetName()+" ");
			seged = seged + c.GetName()+" ";
		}
		System.out.println();
		el.SetOsszString(seged);
	}
	
	public void GetResourceName() {
		if(layers == 0) {
			if(resource != null) {
				System.out.println(resource.GetName());
				el.SetOsszString(resource.GetName());
			}
			else {
				System.out.println("Core: empty");
				el.SetOsszString("Core: empty");
			}
		}
		else {
			System.out.println("Core: unknown");
			el.SetOsszString("Core: unknown");
		}
	}
	
	public void GetResourceNameForSure() {
		if(resource != null) {
			System.out.println("Resource: " + resource.GetName());
			el.SetOsszString("Resource: " + resource.GetName());
		}
		else {
			System.out.println("Resource: empty");
			el.SetOsszString("Resource: empty");
		}
	}
	
	@Override
	public void PrintNeighbor() {
		System.out.println("Asteroid " + id);
		el.SetOsszString("Asteroid " + id);
	}
	
	@Override
	public Asteroid GetOtherAsteroid() {
		return this;
	}
}
