package monke;

public class Iron extends Resource{
	
	String GetName() {
		return "iron";
	}
}
