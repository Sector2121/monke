package monke;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Ellenorzo ell = new Ellenorzo();
		Game game = new Game();
		Scanner myObj = new Scanner(System.in);
	    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	    String[] cmd = new String[5];
	    int teleportCount = 1;
	    System.out.println("Adja meg milyen fajta tesztelest szeretne csinalni(kezi, kesz, exit): ");
		try {
			cmd[0] = br.readLine();
		} catch (IOException e) {
			System.out.println(e);
		}
		if (cmd.length == 0 || cmd[0].equals("")) {
		}
		else if(cmd[0].equals("kesz")) {
			while(true) {
				System.out.println("Mely tesztet szeretne futtatni?: ");
				try {
					cmd[0] = br.readLine();
				} catch (IOException e) {
					System.out.println(e);
				}
				if(cmd[0].equals("exit"))
					break;
				String tesztnev = cmd[0];
				ArrayList<String> parancsok = new ArrayList<>();
				try {
			    	parancsok = ell.TesztBeolvaso(cmd[0]);
				} catch (Exception e) {
					System.out.println(e);
				}
		    	for (String seged : parancsok) {
		    		cmd = seged.split(" ");
		    		if (cmd[0].equals("exit")) {
						break;
					} else if (cmd[0].equals("Create_settlers")) {
						System.out.println("Settlers successfully created!");
						ell.SetOsszString("Settlers successfully created!");
						for (int i=1;i<cmd.length;i++) {
							Settler s = new Settler(game, cmd[i]);
						}
					} else if (cmd[0].equals("Create_ufos")) {
						System.out.println("The Ufos have been created!");
						ell.SetOsszString("The Ufos have been created!");
						for (int i=1;i<cmd.length;i++) {
							Ufo u = new Ufo(game, cmd[i]);
						}
					} else if (cmd[0].equals("Create_asteroids")) {
						System.out.println("Asteroids successfully created!");
						ell.SetOsszString("Asteroids successfully created!");
						for (int i=1;i<=Integer.parseInt(cmd[1]);i++) {
							Random rand = new Random();
							int random = rand.nextInt(4) + 1;
							Resource r;
							if(random == 1) {
								r = new Iron();
							}
							else if (random == 2) {
								r = new Carbon();
							}
							else if (random == 3) {
								r = new Waterice();
							}
							else {
								r = new Uranium();
							}
							Asteroid a = new Asteroid(game, i, r);
						}
					} else if (cmd[0].equals("Start_settlers")) {
						System.out.println("Settlers start asteroid set!");
						ell.SetOsszString("Settlers start asteroid set!");
						for (Settler s : game.GetSettlers()) {
							s.SetAsteroid(game.GetAsteroid().get(Integer.parseInt(cmd[1])-1));
							game.GetAsteroid().get(Integer.parseInt(cmd[1])-1).AddCreature(s);
						}
					} else if (cmd[0].equals("Start_ufos")) {
						System.out.println("Ufos start asteroid set!");
						ell.SetOsszString("Ufos start asteroid set!");
						for (Ufo u : game.GetUfos()) {
							u.SetAsteroid(game.GetAsteroid().get(Integer.parseInt(cmd[1])-1));
							game.GetAsteroid().get(Integer.parseInt(cmd[1])-1).AddCreature(u);
						}
					} else if (cmd[0].equals("Move")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								for(Asteroid a : game.GetAsteroid())
									if(a.GetId() == Integer.parseInt(cmd[2]))
									s.Move(a);
									break;
							}
						}
					} else if (cmd[0].equals("List_neighbors")) {
						System.out.println("-------------------------------------------------------------------------------------");
						ell.SetOsszString("-------------------------------------------------------------------------------------");
						System.out.println("Neighbors: ");
						ell.SetOsszString("Neighbors: ");
						int id = Integer.parseInt(cmd[1]);
						ArrayList<Asteroid> list = game.GetAsteroid();
						ArrayList<Travel> neighbors = new ArrayList<Travel>();
		
						neighbors = list.get(id-1).GetNeighbors();
						for(Travel t : neighbors) {
							t.PrintNeighbor();
						}
						System.out.println("-------------------------------------------------------------------------------------");
						ell.SetOsszString("-------------------------------------------------------------------------------------");
					} else if (cmd[0].equals("Drill")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								s.Drill();
								break;
							}
						}
					} else if (cmd[0].equals("Mine")) {
						boolean found = false;
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								s.Mine();
								found = true;
								break;
							}
						}
						if(found == false) {
							for (Ufo u : game.GetUfos()) { 
								if(u.GetName().equals(cmd[1])) {
									u.Mine();
									break;
								}
							}
						}
					} else if (cmd[0].equals("Build")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								if(cmd[2].equals("robot")) {
									s.BuildRobot(cmd[3]);
								}
								else if (cmd[2].equals("teleport")) {
									s.BuildTeleport();
								}
								else {
									System.out.println("You can only build teleport or robot!");
									ell.SetOsszString("You can only build teleport or robot!");
								}
								break;
							}
						}
					} else if (cmd[0].equals("Place_teleport")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								s.PlaceTeleport(s.GetAsteroid());
								break;
							}
						}
					} else if (cmd[0].equals("Replace_resource")) {
						boolean cont = true;
						Resource r;
						if(cmd[2].equals("uranium")) {
							r = new Uranium();
						}
						else if(cmd[2].equals("waterice")) {
							r = new Waterice();
						}
						else if(cmd[2].equals("iron")) {
							r = new Iron();
						}
						else if(cmd[2].equals("carbon")) {
							r = new Carbon();
						}
						else {
							r = null;
							cont = false;
							System.out.println("The command is invalid");
							ell.SetOsszString("The command is invalid");
						}
						if(cont == true) {
							for (Settler s : game.GetSettlers()) {
								if(s.GetName().equals(cmd[1])) {
									s.PlaceResource(r);
									break;
								}
							}
						}
					} else if (cmd[0].equals("Skip")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								s.Skip();
								break;
							}
						}
					} else if (cmd[0].equals("Give_up")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								s.GiveUp();
								break;
							}
						}
					} else if (cmd[0].equals("Step")) {
						game.Step();
					} else if (cmd[0].equals("Stat")) {
						boolean found = false;
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								found = true;
								System.out.println("-------------------------------------------------------------------------------------");
								ell.SetOsszString("-------------------------------------------------------------------------------------");
								System.out.println("Your settlers statistics are the following:");
								ell.SetOsszString("Your settlers statistics are the following:");
								System.out.println("Name: "+s.GetName());
								ell.SetOsszString("Name: "+s.GetName());
								s.ListAllResourceName();
								System.out.println("Asteroid ID: "+s.GetAsteroid().GetId());
								ell.SetOsszString("Asteroid ID: "+s.GetAsteroid().GetId());
								s.GetAsteroid().GetResourceName();
								System.out.println("Weather: "+s.GetAsteroid().GetWeather());
								ell.SetOsszString("Weather: "+s.GetAsteroid().GetWeather());
								System.out.println("Teleport: "+s.GetHasTpk());
								ell.SetOsszString("Teleport: "+s.GetHasTpk());
								s.GetAsteroid().GetOtherCreaturesName(s);
								System.out.println("-------------------------------------------------------------------------------------");
								ell.SetOsszString("-------------------------------------------------------------------------------------");
								break;
							}
						}
						if(found == false) {
							System.out.println("That is not a valid parameter!");
							ell.SetOsszString("That is not a valid parameter!");
						}
					} else if (cmd[0].equals("Set_weather")) {
						for(Asteroid a : game.GetAsteroid()) {
							if(a.GetId() == Integer.parseInt(cmd[1])) {
								a.SetWeather(cmd[2]);
								if(cmd[2].equals("hot")) {
									a.SetCloseToSun(true);
								}
								else {
									a.SetCloseToSun(false);
								}
								break;
							}
						}
					} else if (cmd[0].equals("Set_resource")) {
						boolean cont = true;
						Resource r;
						if(cmd[2].equals("uranium")) {
							r = new Uranium();
						}
						else if(cmd[2].equals("waterice")) {
							r = new Waterice();
						}
						else if(cmd[2].equals("iron")) {
							r = new Iron();
						}
						else if(cmd[2].equals("carbon")) {
							r = new Carbon();
						}
						else if(cmd[2].equals("null")) {
							r = null;
						}
						else {
							r = null;
							cont = false;
							System.out.println("The command is invalid");
							ell.SetOsszString("The command is invalid");
						}
						if(cont == true) {
							for(Asteroid a : game.GetAsteroid()) {
								if(a.GetId() == Integer.parseInt(cmd[1])) {
									a.SetResource(r);
									break;
								}
							}
						}
					} else if (cmd[0].equals("Set_layer")) {
						for(Asteroid a : game.GetAsteroid()) {
							if(a.GetId() == Integer.parseInt(cmd[1])) {
								a.SetLayers(Integer.parseInt(cmd[2]));
								break;
							}
						}
					} else if (cmd[0].equals("Sunstorm")) {
						game.GetSun().SunStorm();
					} else if (cmd[0].equals("Add_resource")) {
						boolean cont = true;
						Resource r;
						if(cmd[2].equals("uranium")) {
							r = new Uranium();
						}
						else if(cmd[2].equals("waterice")) {
							r = new Waterice();
						}
						else if(cmd[2].equals("iron")) {
							r = new Iron();
						}
						else if(cmd[2].equals("carbon")) {
							r = new Carbon();
						}
						else {
							r = null;
							cont = false;
							System.out.println("The command is invalid");
							ell.SetOsszString("The command is invalid");
						}
						if(cont == true) {
							for (Settler s : game.GetSettlers()) {
								if(s.GetName().equals(cmd[1])) {
									try {
										s.AddResource(r);
									}
									catch (Exception e) {}
									break;
								}
							}
						}
					} else if (cmd[0].equals("Set_resource_settler")) {
						String nev = cmd[1];
						int n = Integer.parseInt(cmd[2]);
						for(Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1]) ) {
								s.SetResources(n);
								break;
							}
						}
					} else if (cmd[0].equals("Create_robot")) {
						String nev = cmd[2];
						int id = Integer.parseInt(cmd[1]);
						Robot robi = new Robot(game, game.GetAsteroid().get(id-1), nev);
						System.out.println("Robot successfully created!");
						ell.SetOsszString("Robot successfully created!");
					} else if (cmd[0].equals("Create_teleport")) {
						Teleport t1 = new Teleport(game, teleportCount++);
						Teleport t2 = new Teleport(game, teleportCount++);
						t1.SetPair(t2);
						t2.SetPair(t1);
						for(Asteroid a : game.GetAsteroid()) {
							if(a.GetId() == Integer.parseInt(cmd[1])) {
								t1.SetAsteroid(a);
								game.AddTeleport(t1);
								a.AddNewNeighbor(t1);
							}
							if(a.GetId() == Integer.parseInt(cmd[2])) {
								t2.SetAsteroid(a);
								game.AddTeleport(t2);
								a.AddNewNeighbor(t2);
							}
						}
						System.out.println("Teleport created and set!");
						ell.SetOsszString("Teleport created and set!");
					} else if (cmd[0].equals("Add_teleport")) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								if(s.GetHasTpk() >= 2) {
									break;
								}
								else {
									s.AddTeleport();
									break;
								}
							}
						}
					} else if (cmd[0].equals("Set_neighbor")) {
						System.out.println("Neighbor successfully set!");
						ell.SetOsszString("Neighbor successfully set!");
						int id1 = Integer.parseInt(cmd[1]);
						int id2 = Integer.parseInt(cmd[2]);
						ArrayList<Asteroid> list = new ArrayList<Asteroid>();
						list = game.GetAsteroid();
						list.get(id1-1).AddNewNeighbor(list.get(id2-1));
						list.get(id2-1).AddNewNeighbor(list.get(id1-1));
					} else if (cmd[0].equals("Reset")) {
						teleportCount = 1;
						game.Reset();
					} else if (cmd[0].equals("Stat_asteroid")) {
						boolean found = false;
						if(game.GetAsteroid()!=null) {
							for(Asteroid a : game.GetAsteroid()) {
								if(a.GetId() == Integer.parseInt(cmd[1])) {
									found = true;
									System.out.println("-------------------------------------------------------------------------------------");
									ell.SetOsszString("-------------------------------------------------------------------------------------");
									System.out.println("Asteroid "+a.GetId()+" stat:");
									ell.SetOsszString("Asteroid "+a.GetId()+" stat:");
									System.out.println("Layers: "+a.GetLayers());
									ell.SetOsszString("Layers: "+a.GetLayers());
									a.GetResourceNameForSure();
									System.out.println("Weather: "+a.GetWeather());
									ell.SetOsszString("Weather: "+a.GetWeather());
									a.GetCreaturesName();
									System.out.println("-------------------------------------------------------------------------------------");
									ell.SetOsszString("-------------------------------------------------------------------------------------");
									break;
								}
							}
						}
						if(found == false) {
							System.out.println("That is not a valid parameter!");
							ell.SetOsszString("That is not a valid parameter!");
						}
					}
					else {
						System.out.println("'" + cmd[0] +"' is not recognized command");
					}
		    	}
		    	try {
			    	ell.EllenorzoFv(tesztnev + "elvart");
				} catch (Exception e) {
					System.out.println(e);
				}
			}
	    }else if(cmd[0].equals("kezi")) {
	    	System.out.println("-------------------------------------------------------------------------------------");
	    	System.out.println("Create_settlers <settler name> <settler name>...");
	    	System.out.println("Create_settlers <settler name> <settler name>...");
			System.out.println("Create_ufos <ufo name> <ufo name>...");
			System.out.println("Create_asteroids <asteroid number>");
			System.out.println("Start_settlers <aszteroida id>");
			System.out.println("Start_ufos <aszteroida id>");
			System.out.println("Move <settler/robot/ufo name> <aszteroida id>");
			System.out.println("List_neighbors <asteroid id>");
			System.out.println("Drill <settler/robot name>");
			System.out.println("Mine <settler/ufo name>");
			System.out.println("Build <settler name> <object> <name, if robot>");
			System.out.println("Place_teleport <settler name>");
			System.out.println("Replace_resource <settler name> <resource type>");
			System.out.println("Skip <settler name>");
			System.out.println("Give_up <settler name>");
			System.out.println("Step");
			System.out.println("Set_weather <asteroid id> <temperature>");
			System.out.println("Set_resource <asteroid id> <resource type>");
			System.out.println("Set_layer <asteroid id> <number>");
			System.out.println("Sunstorm");
			System.out.println("Add_resource <settler name> <resource type>");
			System.out.println("Set_resource_settler <settler name > <number>");
			System.out.println("Create_robot <asteroid id> <robot id>");
			System.out.println("Create_teleport <asteroid id> <asteroid id>");
			System.out.println("Add_teleport <settler name>");
			System.out.println("Set_neighbor <asteroid id> <asteroid id>");
			System.out.println("Reset");
			System.out.println("Stat_asteroid <asteroid id>");
			System.out.println("List_commands");
			System.out.println("-------------------------------------------------------------------------------------");
			while (true) {
				try {
					cmd = br.readLine().split(" ");
				} catch (IOException e) {
					System.out.println(e); 
				}
				if (cmd.length == 0 || cmd[0].equals("")) {
				}	
				if (cmd[0].equals("exit")) {
					break;
				} else if (cmd[0].equals("List_commands")) {
					System.out.println("-------------------------------------------------------------------------------------");
					System.out.println("Create_settlers <settler name> <settler name>...");
					System.out.println("Create_ufos <ufo name> <ufo name>...");
					System.out.println("Create_asteroids <asteroid number>");
					System.out.println("Start_settlers <aszteroida id>");
					System.out.println("Start_ufos <aszteroida id>");
					System.out.println("Move <settler/robot/ufo name> <aszteroida id>");
					System.out.println("List_neighbors <asteroid id>");
					System.out.println("Drill <settler/robot name>");
					System.out.println("Mine <settler/ufo name>");
					System.out.println("Build <settler name> <object> <name, if robot>");
					System.out.println("Place_teleport <settler name>");
					System.out.println("Replace_resource <settler name> <resource type>");
					System.out.println("Skip <settler name>");
					System.out.println("Give_up <settler name>");
					System.out.println("Step");
					System.out.println("Set_weather <asteroid id> <temperature>");
					System.out.println("Set_resource <asteroid id> <resource type>");
					System.out.println("Set_layer <asteroid id> <number>");
					System.out.println("Sunstorm");
					System.out.println("Add_resource <settler name> <resource type>");
					System.out.println("Set_resource_settler <settler name > <number>");
					System.out.println("Create_robot <asteroid id> <robot id>");
					System.out.println("Create_teleport <asteroid id> <asteroid id>");
					System.out.println("Add_teleport <settler name>");
					System.out.println("Set_neighbor <asteroid id> <asteroid id>");
					System.out.println("Reset");
					System.out.println("Stat_asteroid <asteroid id>");
					System.out.println("List_commands");
					System.out.println("-------------------------------------------------------------------------------------");
				} else if (cmd[0].equals("Create_settlers")) {
					System.out.println("Settlers successfully created!");
					ell.SetOsszString("Settlers successfully created!");
					for (int i=1;i<cmd.length;i++) {
						Settler s = new Settler(game, cmd[i]);
					}
				} else if (cmd[0].equals("Create_ufos")) {
					System.out.println("The Ufos have been created!");
					ell.SetOsszString("The Ufos have been created!");
					for (int i=1;i<cmd.length;i++) {
						Ufo u = new Ufo(game, cmd[i]);
					}
				} else if (cmd[0].equals("Create_asteroids")) {
					System.out.println("Asteroids successfully created!");
					ell.SetOsszString("Asteroids successfully created!");
					for (int i=1;i<=Integer.parseInt(cmd[1]);i++) {
						Random rand = new Random();
						int random = rand.nextInt(4) + 1;
						Resource r;
						if(random == 1) {
							r = new Iron();
						}
						else if (random == 2) {
							r = new Carbon();
						}
						else if (random == 3) {
							r = new Waterice();
						}
						else {
							r = new Uranium();
						}
						Asteroid a = new Asteroid(game, i, r);
					}
				} else if (cmd[0].equals("Start_settlers")) {
					System.out.println("Settlers start asteroid set!");
					ell.SetOsszString("Settlers start asteroid set!");
					for (Settler s : game.GetSettlers()) {
						s.SetAsteroid(game.GetAsteroid().get(Integer.parseInt(cmd[1])-1));
						game.GetAsteroid().get(Integer.parseInt(cmd[1])-1).AddCreature(s);
					}
				} else if (cmd[0].equals("Start_ufos")) {
					System.out.println("Ufos start asteroid set!");
					ell.SetOsszString("Ufos start asteroid set!");
					for (Ufo u : game.GetUfos()) {
						u.SetAsteroid(game.GetAsteroid().get(Integer.parseInt(cmd[1])-1));
						game.GetAsteroid().get(Integer.parseInt(cmd[1])-1).AddCreature(u);
					}
				} else if (cmd[0].equals("Move")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							for(Asteroid a : game.GetAsteroid())
								if(a.GetId() == Integer.parseInt(cmd[2]))
								s.Move(a);
								break;
						}
					}
				} else if (cmd[0].equals("List_neighbors")) {
					System.out.println("-------------------------------------------------------------------------------------");
					ell.SetOsszString("-------------------------------------------------------------------------------------");
					System.out.println("Neighbors: ");
					ell.SetOsszString("Neighbors: ");
					int id = Integer.parseInt(cmd[1]);
					ArrayList<Asteroid> list = game.GetAsteroid();
					ArrayList<Travel> neighbors = new ArrayList<Travel>();
	
					neighbors = list.get(id-1).GetNeighbors();
					for(Travel t : neighbors) {
						t.PrintNeighbor();
					}
					System.out.println("-------------------------------------------------------------------------------------");
					ell.SetOsszString("-------------------------------------------------------------------------------------");
				} else if (cmd[0].equals("Drill")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							s.Drill();
							break;
						}
					}
				} else if (cmd[0].equals("Mine")) {
					boolean found = false;
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							s.Mine();
							found = true;
							break;
						}
					}
					if(found == false) {
						for (Ufo u : game.GetUfos()) { 
							if(u.GetName().equals(cmd[1])) {
								u.Mine();
								break;
							}
						}
					}
				} else if (cmd[0].equals("Build")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							if(cmd[2].equals("robot")) {
								s.BuildRobot(cmd[3]);
							}
							else if (cmd[2].equals("teleport")) {
								s.BuildTeleport();
							}
							else {
								System.out.println("You can only build teleport or robot!");
								ell.SetOsszString("You can only build teleport or robot!");
							}
							break;
						}
					}
				} else if (cmd[0].equals("Place_teleport")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							s.PlaceTeleport(s.GetAsteroid());
							break;
						}
					}
				} else if (cmd[0].equals("Replace_resource")) {
					boolean cont = true;
					Resource r;
					if(cmd[2].equals("uranium")) {
						r = new Uranium();
					}
					else if(cmd[2].equals("waterice")) {
						r = new Waterice();
					}
					else if(cmd[2].equals("iron")) {
						r = new Iron();
					}
					else if(cmd[2].equals("carbon")) {
						r = new Carbon();
					}
					else {
						r = null;
						cont = false;
						System.out.println("The command is invalid");
						ell.SetOsszString("The command is invalid");
					}
					if(cont == true) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								s.PlaceResource(r);
								break;
							}
						}
					}
				} else if (cmd[0].equals("Skip")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							s.Skip();
							break;
						}
					}
				} else if (cmd[0].equals("Give_up")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							s.GiveUp();
							break;
						}
					}
				} else if (cmd[0].equals("Step")) {
					game.Step();
				} else if (cmd[0].equals("Stat")) {
					boolean found = false;
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							found = true;
							System.out.println("-------------------------------------------------------------------------------------");
							ell.SetOsszString("-------------------------------------------------------------------------------------");
							System.out.println("Your settlers statistics are the following:");
							ell.SetOsszString("Your settlers statistics are the following:");
							System.out.println("Name: "+s.GetName());
							ell.SetOsszString("Name: "+s.GetName());
							s.ListAllResourceName();
							System.out.println("Asteroid ID: "+s.GetAsteroid().GetId());
							ell.SetOsszString("Asteroid ID: "+s.GetAsteroid().GetId());
							s.GetAsteroid().GetResourceName();
							System.out.println("Weather: "+s.GetAsteroid().GetWeather());
							ell.SetOsszString("Weather: "+s.GetAsteroid().GetWeather());
							System.out.println("Teleport: "+s.GetHasTpk());
							ell.SetOsszString("Teleport: "+s.GetHasTpk());
							s.GetAsteroid().GetOtherCreaturesName(s);
							System.out.println("-------------------------------------------------------------------------------------");
							ell.SetOsszString("-------------------------------------------------------------------------------------");
							break;
						}
					}
					if(found == false) {
						System.out.println("That is not a valid parameter!");
						ell.SetOsszString("That is not a valid parameter!");
					}
				} else if (cmd[0].equals("Set_weather")) {
					for(Asteroid a : game.GetAsteroid()) {
						if(a.GetId() == Integer.parseInt(cmd[1])) {
							a.SetWeather(cmd[2]);
							if(cmd[2].equals("hot")) {
								a.SetCloseToSun(true);
							}
							else {
								a.SetCloseToSun(false);
							}
							break;
						}
					}
				} else if (cmd[0].equals("Set_resource")) {
					boolean cont = true;
					Resource r;
					if(cmd[2].equals("uranium")) {
						r = new Uranium();
					}
					else if(cmd[2].equals("waterice")) {
						r = new Waterice();
					}
					else if(cmd[2].equals("iron")) {
						r = new Iron();
					}
					else if(cmd[2].equals("carbon")) {
						r = new Carbon();
					}
					else if(cmd[2].equals("null")) {
						r = null;
					}
					else {
						r = null;
						cont = false;
						System.out.println("The command is invalid");
						ell.SetOsszString("The command is invalid");
					}
					if(cont == true) {
						for(Asteroid a : game.GetAsteroid()) {
							if(a.GetId() == Integer.parseInt(cmd[1])) {
								a.SetResource(r);
								break;
							}
						}
					}
				} else if (cmd[0].equals("Set_layer")) {
					for(Asteroid a : game.GetAsteroid()) {
						if(a.GetId() == Integer.parseInt(cmd[1])) {
							a.SetLayers(Integer.parseInt(cmd[2]));
							break;
						}
					}
				} else if (cmd[0].equals("Sunstorm")) {
					game.GetSun().SunStorm();
				} else if (cmd[0].equals("Add_resource")) {
					boolean cont = true;
					Resource r;
					if(cmd[2].equals("uranium")) {
						r = new Uranium();
					}
					else if(cmd[2].equals("waterice")) {
						r = new Waterice();
					}
					else if(cmd[2].equals("iron")) {
						r = new Iron();
					}
					else if(cmd[2].equals("carbon")) {
						r = new Carbon();
					}
					else {
						r = null;
						cont = false;
						System.out.println("The command is invalid");
						ell.SetOsszString("The command is invalid");
					}
					if(cont == true) {
						for (Settler s : game.GetSettlers()) {
							if(s.GetName().equals(cmd[1])) {
								try {
									s.AddResource(r);
								}
								catch (Exception e) {}
								break;
							}
						}
					}
				} else if (cmd[0].equals("Set_resource_settler")) {
					String nev = cmd[1];
					int n = Integer.parseInt(cmd[2]);
					for(Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1]) ) {
							s.SetResources(n);
							break;
						}
					}
				} else if (cmd[0].equals("Create_robot")) {
					String nev = cmd[2];
					int id = Integer.parseInt(cmd[1]);
					Robot robi = new Robot(game, game.GetAsteroid().get(id-1), nev);
					System.out.println("Robot successfully created!");
					ell.SetOsszString("Robot successfully created!");
				} else if (cmd[0].equals("Create_teleport")) {
					Teleport t1 = new Teleport(game, teleportCount++);
					Teleport t2 = new Teleport(game, teleportCount++);
					t1.SetPair(t2);
					t2.SetPair(t1);
					for(Asteroid a : game.GetAsteroid()) {
						if(a.GetId() == Integer.parseInt(cmd[1])) {
							t1.SetAsteroid(a);
							game.AddTeleport(t1);
							a.AddNewNeighbor(t1);
						}
						if(a.GetId() == Integer.parseInt(cmd[2])) {
							t2.SetAsteroid(a);
							game.AddTeleport(t2);
							a.AddNewNeighbor(t2);
						}
					}
					System.out.println("Teleport created and set!");
					ell.SetOsszString("Teleport created and set!");
				} else if (cmd[0].equals("Add_teleport")) {
					for (Settler s : game.GetSettlers()) {
						if(s.GetName().equals(cmd[1])) {
							if(s.GetHasTpk() >= 2) {
								break;
							}
							else {
								s.AddTeleport();
								break;
							}
						}
					}
				} else if (cmd[0].equals("Set_neighbor")) {
					System.out.println("Neighbor successfully set!");
					ell.SetOsszString("Neighbor successfully set!");
					int id1 = Integer.parseInt(cmd[1]);
					int id2 = Integer.parseInt(cmd[2]);
					ArrayList<Asteroid> list = new ArrayList<Asteroid>();
					list = game.GetAsteroid();
					list.get(id1-1).AddNewNeighbor(list.get(id2-1));
					list.get(id2-1).AddNewNeighbor(list.get(id1-1));
				} else if (cmd[0].equals("Reset")) {
					teleportCount = 1;
					game.Reset();
				} else if (cmd[0].equals("Stat_asteroid")) {
					boolean found = false;
					if(game.GetAsteroid()!=null) {
						for(Asteroid a : game.GetAsteroid()) {
							if(a.GetId() == Integer.parseInt(cmd[1])) {
								found = true;
								System.out.println("-------------------------------------------------------------------------------------");
								ell.SetOsszString("-------------------------------------------------------------------------------------");
								System.out.println("Asteroid "+a.GetId()+" stat:");
								ell.SetOsszString("Asteroid "+a.GetId()+" stat:");
								System.out.println("Layers: "+a.GetLayers());
								ell.SetOsszString("Layers: "+a.GetLayers());
								a.GetResourceNameForSure();
								System.out.println("Weather: "+a.GetWeather());
								ell.SetOsszString("Weather: "+a.GetWeather());
								a.GetCreaturesName();
								System.out.println("-------------------------------------------------------------------------------------");
								ell.SetOsszString("-------------------------------------------------------------------------------------");
								break;
							}
						}
					}
					if(found == false) {
						System.out.println("That is not a valid parameter!");
						ell.SetOsszString("That is not a valid parameter!");
					}
				}
				else {
					System.out.println("'" + cmd[0] +"' is not recognized command");
				}
			}
	    }
	    else if(cmd[0].equals("exit")) {
	    	System.out.println("Adios amigo!");
	    }
	}
}
