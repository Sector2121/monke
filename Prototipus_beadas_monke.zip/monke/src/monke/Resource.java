package monke;

abstract class Resource {

	public void CloseToSun(Asteroid a) {
		
	}
	
	/**
	 * nev kiiras
	 */
	abstract String GetName();
}
