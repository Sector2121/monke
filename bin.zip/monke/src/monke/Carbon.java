package monke;

public class Carbon extends Resource{

}
