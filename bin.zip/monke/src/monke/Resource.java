package monke;

public class Resource {

	public void CloseToSun(Asteroid a) {
		
	}
}
