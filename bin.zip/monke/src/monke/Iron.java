package monke;

public class Iron extends Resource{

}
