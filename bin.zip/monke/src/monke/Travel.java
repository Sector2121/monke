package monke;

public interface Travel {
	public void Accept(Creature c);
}
